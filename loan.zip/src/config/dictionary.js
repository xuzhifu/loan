/**
 * @file
 * @author: lzb
 * @params: 参数说明
 * @history:
 * Date      Version Remarks
 * ========= ======= ==================================
 * 2018/7/27       1.0     First version
 *
 */
/**
 * 左侧边栏导航
 * @type {0: 门店用户, 1: 客户用户}
 */
